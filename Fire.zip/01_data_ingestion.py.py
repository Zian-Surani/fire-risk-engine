# Databricks notebook source
# DBTITLE 1,Bronze Layer Documentation
# MAGIC %md
# MAGIC # BRONZE LAYER: Raw Data Ingestion from San Francisco Open Data
# MAGIC
# MAGIC ## Purpose
# MAGIC Ingest raw fire-related datasets from the San Francisco Open Data Portal via Socrata API. This layer maintains data in its original form with minimal transformation, serving as the foundation for downstream processing in the Silver and Gold layers.
# MAGIC
# MAGIC ## Architecture
# MAGIC **Data Source**: San Francisco Open Data Portal (data.sfgov.org)
# MAGIC **API**: Socrata Open Data API (SODA)
# MAGIC **Authentication**: API token-based access
# MAGIC **Load Strategy**: Full refresh with overwrite mode
# MAGIC
# MAGIC ## Datasets Ingested (5 Total)
# MAGIC
# MAGIC ### 1. Fire Incidents (bronze_fire_incidents)
# MAGIC **Dataset ID**: wr8u-xric
# MAGIC **Record Limit**: 50,000
# MAGIC **Description**: Historical fire incident reports including location, property damage, casualties, and response details
# MAGIC **Key Fields**:
# MAGIC - incident_number, call_number: Unique identifiers
# MAGIC - incident_date: When the fire occurred
# MAGIC - address, zipcode, supervisor_district, neighborhood_district: Location information
# MAGIC - estimated_property_loss: Financial impact
# MAGIC - fire_fatalities, fire_injuries, civilian_injuries: Human impact
# MAGIC - primary_situation, property_use, ignition_cause: Incident classification
# MAGIC - battalion, station_area, number_of_alarms: Response details
# MAGIC
# MAGIC ### 2. Fire Calls (bronze_fire_calls)
# MAGIC **Dataset ID**: nuek-vuh3
# MAGIC **Record Limit**: 50,000
# MAGIC **Description**: Emergency call records with timestamps for received, dispatched, and response times
# MAGIC **Key Fields**:
# MAGIC - call_number, incident_number: Linking identifiers
# MAGIC - call_type: Type of emergency
# MAGIC - received_dttm, dispatch_dttm, response_dttm: Temporal tracking
# MAGIC - station_area, disposition: Response details
# MAGIC - address: Location
# MAGIC
# MAGIC ### 3. Fire Violations (bronze_fire_violations)
# MAGIC **Dataset ID**: 6a9r-agq8
# MAGIC **Record Limit**: 50,000 (actual: 497 records)
# MAGIC **Description**: Code violations and compliance issues identified during inspections
# MAGIC **Key Fields**:
# MAGIC - violation_number: Unique identifier
# MAGIC - address, district: Location
# MAGIC - violation_date: When violation was recorded
# MAGIC - violation_type, violation_status, severity_level: Classification
# MAGIC
# MAGIC ### 4. Fire Inspections (bronze_fire_inspections)
# MAGIC **Dataset ID**: vu4v-9j9k
# MAGIC **Record Limit**: 50,000 (actual: 432,680 records)
# MAGIC **Description**: Building and property inspection records
# MAGIC **Key Fields**:
# MAGIC - inspection_number: Unique identifier
# MAGIC - address, district: Location
# MAGIC - inspection_type, inspection_date: Classification and timing
# MAGIC - disposition, violations_found: Inspection results
# MAGIC
# MAGIC ### 5. Fire Permits (bronze_fire_permits)
# MAGIC **Dataset ID**: 8g4x-5xve
# MAGIC **Record Limit**: 50,000 (actual: 84,526 records)
# MAGIC **Description**: Fire safety permits and compliance documentation
# MAGIC **Key Fields**:
# MAGIC - permit_number: Unique identifier
# MAGIC - address, district: Location (note: column name is "Permit Address")
# MAGIC - permit_type, permit_status: Classification
# MAGIC - permit_start_date, permit_expiration_date: Validity period
# MAGIC
# MAGIC ## Data Engineering Approach
# MAGIC **API Integration**:
# MAGIC - Use Socrata Python client (sodapy) for API access
# MAGIC - Implement field-level filtering to extract only required columns
# MAGIC - Apply type casting for numeric fields (property loss, counts)
# MAGIC - Handle missing values gracefully with try-except blocks
# MAGIC
# MAGIC **Schema Management**:
# MAGIC - Define explicit Spark StructType schemas for each dataset
# MAGIC - Preserve original data types (StringType for most fields)
# MAGIC - Convert to Delta format for ACID transactions and time travel
# MAGIC
# MAGIC **Load Pattern**:
# MAGIC - Mode: Overwrite (full refresh on each run)
# MAGIC - Format: Delta (Databricks optimized storage)
# MAGIC - Table naming convention: bronze_{dataset_type}
# MAGIC
# MAGIC ## Data Quality Considerations
# MAGIC **Known Limitations**:
# MAGIC - Violations dataset: Only 497 records available, limited coverage
# MAGIC - API rate limits: 50,000 records per dataset (may not capture full history)
# MAGIC - Address format variations: Different conventions across datasets
# MAGIC - Missing values: Handled with None/null preservation
# MAGIC
# MAGIC **Mitigation**:
# MAGIC - Field validation during ingestion (safe type casting)
# MAGIC - Consistent null handling across datasets
# MAGIC - Downstream address normalization in Silver layer
# MAGIC
# MAGIC ## System Users
# MAGIC Data engineers and analysts requiring raw source data for exploration, debugging, and auditing. This layer enables:
# MAGIC - Historical data lineage tracking
# MAGIC - Root cause analysis for data quality issues
# MAGIC - Reprocessing of data with updated logic
# MAGIC - Regulatory compliance and audit trails
# MAGIC
# MAGIC ## Version Control
# MAGIC - Version: 1.0 - Initial Production Release
# MAGIC - Last Updated: 2026-04-11
# MAGIC - Data Engineering Team

# COMMAND ----------

print("Ready 🚀")


# COMMAND ----------

# MAGIC %pip install sodapy

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from sodapy import Socrata
from pyspark.sql import SparkSession
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()

client = Socrata("data.sfgov.org", "aqSecqUM01A8KXxYcDf2vnW9g")

data = client.get("wr8u-xric", limit=50000)

required_fields = [
    "incident_number",
    "call_number",
    "incident_date",
    "address",
    "zipcode",
    "battalion",
    "station_area",
    "estimated_property_loss",
    "fire_fatalities",
    "fire_injuries",
    "civilian_injuries",
    "number_of_alarms",
    "primary_situation",
    "property_use",
    "ignition_cause",
    "structure_type",
    "supervisor_district",
    "neighborhood_district"
]

clean_data = []

for row in data:
    filtered = {}

    for k in required_fields:
        val = row.get(k)

        # 🔥 FIX: convert numeric fields safely
        if k in ["estimated_property_loss"]:
            try:
                val = float(val) if val is not None else None
            except:
                val = None

        elif k in ["fire_fatalities", "fire_injuries", "civilian_injuries", "number_of_alarms"]:
            try:
                val = int(val) if val is not None else None
            except:
                val = None

        filtered[k] = val

    clean_data.append(filtered)

# ✅ Schema
schema = StructType([
    StructField("incident_number", StringType(), True),
    StructField("call_number", StringType(), True),
    StructField("incident_date", StringType(), True),
    StructField("address", StringType(), True),
    StructField("zipcode", StringType(), True),
    StructField("battalion", StringType(), True),
    StructField("station_area", StringType(), True),
    StructField("estimated_property_loss", DoubleType(), True),
    StructField("fire_fatalities", IntegerType(), True),
    StructField("fire_injuries", IntegerType(), True),
    StructField("civilian_injuries", IntegerType(), True),
    StructField("number_of_alarms", IntegerType(), True),
    StructField("primary_situation", StringType(), True),
    StructField("property_use", StringType(), True),
    StructField("ignition_cause", StringType(), True),
    StructField("structure_type", StringType(), True),
    StructField("supervisor_district", StringType(), True),
    StructField("neighborhood_district", StringType(), True)
])

df = spark.createDataFrame(clean_data, schema=schema)

df.write.format("delta").mode("overwrite").saveAsTable("bronze_fire_incidents")

print("✅ FINAL CLEAN DATA LOADED")

# COMMAND ----------

from sodapy import Socrata
from pyspark.sql import SparkSession
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()

client = Socrata("data.sfgov.org", "aqSecqUM01A8KXxYcDf2vnW9g")
data = client.get("nuek-vuh3", limit=50000)

required_fields = [
    "call_number",
    "incident_number",
    "call_type",
    "received_dttm",
    "dispatch_dttm",
    "response_dttm",
    "station_area",
    "disposition",
    "address"
]

clean_data = []

for row in data:
    filtered = {k: row.get(k) for k in required_fields}
    clean_data.append(filtered)

from pyspark.sql.types import *

schema = StructType([
    StructField("call_number", StringType(), True),
    StructField("incident_number", StringType(), True),
    StructField("call_type", StringType(), True),
    StructField("received_dttm", StringType(), True),
    StructField("dispatch_dttm", StringType(), True),
    StructField("response_dttm", StringType(), True),
    StructField("station_area", StringType(), True),
    StructField("disposition", StringType(), True),
    StructField("address", StringType(), True)
])

df_calls = spark.createDataFrame(clean_data, schema=schema)

df_calls.write.format("delta").mode("overwrite").saveAsTable("bronze_fire_calls")

print("✅ fire_calls loaded")

# COMMAND ----------

from sodapy import Socrata
from pyspark.sql import SparkSession
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()

client = Socrata("data.sfgov.org", "aqSecqUM01A8KXxYcDf2vnW9g")
data = client.get("6a9r-agq8", limit=50000)

required_fields = [
    "violation_number",
    "address",
    "violation_date",
    "violation_type",
    "violation_status",
    "severity_level",
    "district"
]

clean_data = []

for row in data:
    filtered = {k: row.get(k) for k in required_fields}
    clean_data.append(filtered)

schema = StructType([
    StructField("violation_number", StringType(), True),
    StructField("address", StringType(), True),
    StructField("violation_date", StringType(), True),
    StructField("violation_type", StringType(), True),
    StructField("violation_status", StringType(), True),
    StructField("severity_level", StringType(), True),
    StructField("district", StringType(), True)
])

df_violations = spark.createDataFrame(clean_data, schema=schema)

df_violations.write.format("delta").mode("overwrite").saveAsTable("bronze_fire_violations")

print("✅ fire_violations loaded")

# COMMAND ----------

from sodapy import Socrata
from pyspark.sql import SparkSession
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()

client = Socrata("data.sfgov.org", "aqSecqUM01A8KXxYcDf2vnW9g")
data = client.get("vu4v-9j9k", limit=50000)

required_fields = [
    "inspection_number",
    "address",
    "inspection_type",
    "inspection_date",
    "disposition",
    "district",
    "violations_found"
]

clean_data = []

for row in data:
    filtered = {k: row.get(k) for k in required_fields}
    clean_data.append(filtered)

schema = StructType([
    StructField("inspection_number", StringType(), True),
    StructField("address", StringType(), True),
    StructField("inspection_type", StringType(), True),
    StructField("inspection_date", StringType(), True),
    StructField("disposition", StringType(), True),
    StructField("district", StringType(), True),
    StructField("violations_found", IntegerType(), True)
])

df_inspections = spark.createDataFrame(clean_data, schema=schema)

df_inspections.write.format("delta").mode("overwrite").saveAsTable("bronze_fire_inspections")

print("✅ fire_inspections loaded")

# COMMAND ----------

from sodapy import Socrata
from pyspark.sql import SparkSession
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()

client = Socrata("data.sfgov.org", "aqSecqUM01A8KXxYcDf2vnW9g")
data = client.get("8g4x-5xve", limit=50000)

required_fields = [
    "permit_number",
    "address",
    "permit_type",
    "permit_start_date",
    "permit_expiration_date",
    "permit_status",
    "district"
]

clean_data = []

for row in data:
    filtered = {k: row.get(k) for k in required_fields}
    clean_data.append(filtered)

schema = StructType([
    StructField("permit_number", StringType(), True),
    StructField("address", StringType(), True),
    StructField("permit_type", StringType(), True),
    StructField("permit_start_date", StringType(), True),
    StructField("permit_expiration_date", StringType(), True),
    StructField("permit_status", StringType(), True),
    StructField("district", StringType(), True)
])

df_permits = spark.createDataFrame(clean_data, schema=schema)

df_permits.write.format("delta").mode("overwrite").saveAsTable("bronze_fire_permits")

print("✅ fire_permits loaded")